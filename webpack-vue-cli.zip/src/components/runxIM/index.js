import runxIM from "./runxIM.vue";
export default runxIM;