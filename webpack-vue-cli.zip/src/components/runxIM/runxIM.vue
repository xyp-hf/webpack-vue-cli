<template>
    <div id="runx_im_container">
        <chat></chat>
        <prompt></prompt>
        <comment></comment>
    </div>
</template>

<script lang="js" src="./runxIM.js">
</script>

<style lang="scss" scoped>

</style>

