import prompt from "./prompt.vue";
export default prompt;