import comment from "./comment.vue";
export default comment;