import entryButton from "./entryButton.vue";
export default entryButton;