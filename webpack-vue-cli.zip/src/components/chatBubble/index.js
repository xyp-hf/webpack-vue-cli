import chatBubble from "./chatBubble.vue";
export default chatBubble;